<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Mega Memorama</title>
    <style>
        :root {
            --rosa-principal: #e05286;
            --rosa-fondo: #f9ecef;
            --blanco: #ffffff;
            --morado-botones: #b577ce;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-color: var(--rosa-fondo);
            text-align: center;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header-nav {
            background-color: var(--rosa-principal);
            padding: 5px 40px;
            display: flex;
            justify-content: space-between;
            color: white;
            align-items: center;
        }

        .enlace-capibara {
            display: inline-block;
            transition: transform 0.2s ease-in-out;
            border-radius: 50%;
            overflow: hidden;
            background: white;
            padding: 3px;
            width: 55px;
            height: 55px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .enlace-capibara:hover {
            transform: scale(1.1);
        }

        .img-menu-capibara {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .contenedor-principal {
            display: flex;
            justify-content: center;
            align-items: center;
            flex: 1;
            padding: 20px;
        }

        .contenedor-juego {
            width: 100%;
            max-width: 650px;
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.05);
            border: 4px solid var(--rosa-principal);
        }

        .marcador-memorama {
            display: flex;
            justify-content: space-around;
            background-color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1.3rem;
            font-weight: bold;
            color: var(--morado-botones);
            border: 2px solid #f2d6e4;
            margin-bottom: 15px;
        }

        .grid-tablero {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            perspective: 1000px;
        }

        .carta-memorama {
            background-color: var(--morado-botones);
            color: transparent;
            border: 3px solid var(--rosa-principal);
            border-radius: 12px;
            height: 95px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.4rem;
            font-weight: bold;
            cursor: pointer;
            user-select: none;
            transition: transform 0.3s, background-color 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .carta-memorama:hover {
            transform: scale(1.03);
        }

        .carta-memorama.volteada, .carta-memorama.emparejada {
            background-color: white;
            color: var(--rosa-principal);
            transform: rotateY(180deg);
            cursor: default;
            pointer-events: none;
        }

        .carta-memorama.emparejada {
            border-color: #4caf50;
            color: #4caf50;
        }

        .capa-bloqueo {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(92, 58, 68, 0.6);
            justify-content: center;
            align-items: center;
            z-index: 100;
        }

        .tarjeta-final {
            background: white;
            border: 5px solid var(--rosa-principal);
            padding: 35px;
            border-radius: 20px;
            max-width: 450px;
            width: 90%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            animation: animacionEntrada 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }

        @keyframes animacionEntrada {
            from { transform: scale(0.7); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .contenedor-puntos-finales {
            background-color: var(--rosa-fondo);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            border: 2px dashed var(--rosa-principal);
        }

        .btn-final-volver {
            background-color: var(--morado-botones);
            color: white;
            padding: 14px 35px;
            font-size: 1.2rem;
            font-weight: bold;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            margin-top: 15px;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: 0.2s;
        }

        .btn-final-volver:hover {
            background-color: var(--rosa-principal);
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Mega Memorama </h1>
        <a href="seleccion.php" class="enlace-capibara" title="Volver al Menú Principal">
            <img src="capibara.jpeg" alt="Capibara" class="img-menu-capibara">
        </a>
    </header>

    <div class="contenedor-principal">
        <main class="contenedor-juego">
            
            <div class="marcador-memorama">
                <div>Parejas: <span id="parejas-txt">0 / 8</span></div>
                <div>Intentos: <span id="intentos-txt">0</span></div>
            </div>
            
            <div id="tablero" class="grid-tablero"></div>

        </main>
    </div>

    <div class="capa-bloqueo" id="pantallaFinal">
        <div class="tarjeta-final">
            <h2 id="titulo-final">¡Excelente Trabajo! </h2>
            <p id="mensaje-final">Completaste el memorama nivel experto con éxito.</p>
            <div class="contenedor-puntos-finales">
                <span style="font-size: 1.4rem; font-weight: bold; color: var(--rosa-principal);">Total de Intentos:</span><br>
                <span style="font-size: 3.5rem; font-weight: bold; color: var(--morado-botones);" id="intentos-finales-num">0</span> intentos
            </div>
            <a href="seleccion.php" class="btn-final-volver">Volver al Menú Principal</a>
        </div>
    </div>

    <script>
        const datosBase = [
            { pregunta: "12 × 5", respuesta: "60" },
            { pregunta: "15 × 4", respuesta: "60" },
            { pregunta: "25 × 3", respuesta: "75" },
            { pregunta: "14 × 3", respuesta: "42" },
            { pregunta: "11 × 8", respuesta: "88" },
            { pregunta: "13 × 4", respuesta: "52" },
            { pregunta: "22 × 4", respuesta: "88" },
            { pregunta: "16 × 5", respuesta: "80" }
        ];

        let cartasVolteadas = [];
        let parejasEncontradas = 0;
        let intentos = 0;
        let bloqueandoTablero = false;

        function crearTablero() {
            const contenedorTablero = document.getElementById("tablero");
            if (!contenedorTablero) return;
            contenedorTablero.innerHTML = ""; 

            let listaCartas = [];
            
            datosBase.forEach((item, indice) => {
                listaCartas.push({ texto: item.pregunta, idPareja: indice });
                listaCartas.push({ texto: item.respuesta, idPareja: indice });
            });

            listaCartas.sort(() => Math.random() - 0.5);

            listaCartas.forEach(cartaInfo => {
                const elementoCarta = document.createElement("div");
                elementoCarta.classList.add("carta-memorama");
                elementoCarta.innerText = cartaInfo.texto;
                elementoCarta.dataset.pareja = cartaInfo.idPareja;
                
                elementoCarta.addEventListener("click", voltearCarta);
                
                contenedorTablero.appendChild(elementoCarta);
            });
        }

        function voltearCarta() {
            if (bloqueandoTablero || this.classList.contains("volteada") || this.classList.contains("emparejada")) return;

            this.classList.add("volteada");
            cartasVolteadas.push(this);

            if (cartasVolteadas.length === 2) {
                intentos++;
                document.getElementById("intentos-txt").innerText = intentos;
                verificarPareja();
            }
        }

        function verificarPareja() {
            let [carta1, carta2] = cartasVolteadas;

            if (carta1.dataset.pareja === carta2.dataset.pareja) {
                carta1.classList.add("emparejada");
                carta2.classList.add("emparejada");
                parejasEncontradas++;
                document.getElementById("parejas-txt").innerText = `${parejasEncontradas} / 8`;
                
                cartasVolteadas = [];

                if (parejasEncontradas === 8) {
                    setTimeout(mostrarPantallaFinal, 600);
                }
            } else {
                bloqueandoTablero = true;
                setTimeout(() => {
                    carta1.classList.remove("volteada");
                    carta2.classList.remove("volteada");
                    cartasVolteadas = [];
                    bloqueandoTablero = false;
                }, 1000);
            }
        }

        function mostrarPantallaFinal() {
            document.getElementById("intentos-finales-num").innerText = intentos;
            
            let t = document.getElementById("titulo-final");
            let m = document.getElementById("mensaje-final");

            if (intentos <= 15) {
                t.innerText = "¡Súper Memoria Prodigiosa! ";
                m.innerText = "¡Increíble! Tienes una agilidad mental y una memoria nivel experta digna de admirar.";
            } else {
                t.innerText = "¡Lo Lograste, Campeona! ";
                m.innerText = "¡Muy bien jugado! Lograste resolver todas las multiplicaciones difíciles del memorama.";
            }

            document.getElementById("pantallaFinal").style.display = "flex";
        }

        window.onload = crearTablero;
    </script>
</body>
</html>