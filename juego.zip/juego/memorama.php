<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: iniciar.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Memorama</title>
    <style>
        :root { 
            --rosa-principal: #e05286; 
            --rosa-fondo: #f9ecef; 
            --amarillo-borde: #ffcb42; 
            --blanco: #ffffff; 
            --texto-oscuro: #5c3a44;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); text-align: center; min-height: 100vh; display: flex; flex-direction: column; }
        
        .header-nav { 
            background-color: var(--rosa-principal); 
            padding: 10px 40px; 
            display: flex; 
            justify-content: space-between; 
            color: white; 
            align-items: center; 
        }
        
        .btn-capibara-menu {
            display: inline-block;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 3px solid var(--blanco);
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            transition: transform 0.2s, border-color 0.2s;
        }
        .btn-capibara-menu:hover {
            transform: scale(1.1);
            border-color: #ffcb42;
        }
        .btn-capibara-menu img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .contenedor-principal { display: flex; justify-content: center; align-items: center; flex: 1; padding: 20px; }
        .contenedor-memorama { width: 100%; max-width: 700px; background-color: #fcd7e4; border: 4px solid var(--rosa-principal); border-radius: 15px; padding: 25px; box-shadow: 0 8px 16px rgba(0,0,0,0.05); }
        
        .marcador { display: flex; justify-content: space-around; font-size: 1.3rem; font-weight: bold; color: #b577ce; margin-bottom: 20px; background: var(--blanco); padding: 10px; border-radius: 10px; box-shadow: inset 0 2px 5px rgba(0,0,0,0.05); }
        .tablero-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-top: 20px; }
        
        .carta { height: 120px; position: relative; transform-style: preserve-3d; transition: transform 0.5s; cursor: pointer; }
        .carta.volteada { transform: rotateY(180deg); }
        .carta.emparejada { transform: rotateY(180deg); opacity: 0.7; cursor: default; }
        
        .cara { position: absolute; width: 100%; height: 100%; backface-visibility: hidden; border-radius: 10px; display: flex; justify-content: center; align-items: center; font-weight: bold; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .detras { background-color: var(--rosa-principal); color: white; font-size: 2.5rem; border: 3px solid var(--blanco); }
        .frente { background-color: var(--blanco); color: var(--texto-oscuro); font-size: 1.5rem; transform: rotateY(180deg); border: 3px solid var(--amarillo-borde); padding: 5px; }

        .capa-bloqueo {
            display: none;
            position: fixed; 
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(92, 58, 68, 0.6); 
            justify-content: center; align-items: center;
            z-index: 100;
        }
        .tarjeta-final {
            background: white;
            border: 5px solid var(--rosa-principal);
            padding: 35px;
            border-radius: 20px;
            max-width: 450px;
            width: 90%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            animation: animacionEntrada 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        @keyframes animacionEntrada {
            from { transform: scale(0.7); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .contenedor-datos-finales {
            background-color: var(--rosa-fondo);
            padding: 15px;
            border-radius: 15px;
            margin: 20px 0;
            border: 2px dashed var(--rosa-principal);
            display: flex;
            justify-content: space-around;
            align-items: center;
        }
        .btn-final-volver {
            background-color: #b577ce; color: white;
            padding: 14px 35px; font-size: 1.2rem; font-weight: bold;
            border: none; border-radius: 30px; cursor: pointer;
            margin-top: 15px; text-decoration: none; display: inline-block;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); transition: 0.2s;
        }
        .btn-final-volver:hover { background-color: var(--rosa-principal); transform: translateY(-2px); }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Niñas Matemáticas</h1>
        <a href="seleccion.php" class="btn-capibara-menu" title="Volver al Menú">
            <img src="capibara.jpeg" alt="Menú">
        </a>
    </header>

    <div class="contenedor-principal">
        <main class="contenedor-memorama">
            <div class="marcador">
                <div>Parejas: <span id="parejas">0</span> / 4</div>
                <div>Intentos: <span id="intentos">0</span></div>
            </div>

            <div class="tablero-grid" id="tablero"></div>
        </main>
    </div>

    <div class="capa-bloqueo" id="pantallaFinalMemorama">
        <div class="tarjeta-final">
            <h2 id="titulo-final" style="color: var(--rosa-principal); font-size: 2.2rem; margin-bottom: 10px;">-</h2>
            <p id="mensaje-final" style="font-size: 1.1rem; color: #5c3a44;">-</p>
            
            <div class="contenedor-datos-finales">
                <div>
                    <span style="font-size: 1rem; font-weight: bold; color: var(--rosa-principal);">Intentos totales:</span>
                    <br>
                    <span style="font-size: 2.5rem; font-weight: bold; color: #b577ce;" id="intentos-finales">0</span>
                </div>
            </div>

            <a href="seleccion.php" class="btn-final-volver">Volver al Menú Principal</a>
        </div>
    </div>

    <script>
        const elementos = [
            { id: 1, contenido: "3 x 4" },
            { id: 1, contenido: " = 12 " },
            { id: 2, contenido: "5 x 5" },
            { id: 2, contenido: " = 25 " },
            { id: 3, contenido: "2 x 8" },
            { id: 3, contenido: " = 16 " },
            { id: 4, contenido: "9 x 2" },
            { id: 4, contenido: " = 18 " }
        ];

        let cartasVolteadas = [];
        let parejasContadas = 0;
        let intentosContados = 0;
        let bloqueandoTablero = false;

        function barajar(array) { 
            return array.sort(() => Math.random() - 0.5); 
        }

        function crearTablero() {
            const tablero = document.getElementById("tablero");
            tablero.innerHTML = ""; 
            const mezclados = barajar([...elementos]);

            mezclados.forEach(item => {
                const carta = document.createElement("div");
                carta.classList.add("carta");
                carta.dataset.id = item.id;

                carta.innerHTML = `
                    <div class="cara detras">?</div>
                    <div class="cara frente"><span>${item.contenido}</span></div>
                `;
                carta.addEventListener("click", voltearCarta);
                tablero.appendChild(carta);
            });
        }

        function voltearCarta() {
            if (bloqueandoTablero || this.classList.contains("volteada") || this.classList.contains("emparejada")) return;
            
            this.classList.add("volteada");
            cartasVolteadas.push(this);

            if (cartasVolteadas.length === 2) comprobarPareja();
        }

        function comprobarPareja() {
            intentosContados++;
            document.getElementById("intentos").innerText = intentosContados;
            let [c1, c2] = cartasVolteadas;

            if (c1.dataset.id === c2.dataset.id) {
                parejasContadas++;
                document.getElementById("parejas").innerText = parejasContadas;
                bloqueandoTablero = true;
                
                setTimeout(() => {
                    c1.classList.add("emparejada"); 
                    c2.classList.add("emparejada");
                    resetear();
                    
                    if (parejasContadas === 4) {
                        mostrarFelicitacionFinal();
                    }
                }, 600);
            } else {
                bloqueandoTablero = true;
                setTimeout(() => {
                    c1.classList.remove("volteada"); 
                    c2.classList.remove("volteada");
                    resetear();
                }, 1000);
            }
        }

        function resetear() { 
            cartasVolteadas = []; 
            bloqueandoTablero = false; 
        }

        function mostrarFelicitacionFinal() {
            document.getElementById("intentos-finales").innerText = intentosContados;
            
            let titulo = document.getElementById("titulo-final");
            let mensaje = document.getElementById("mensaje-final");

            if (intentosContados <= 6) {
                titulo.innerText = "¡Súper Memoria! ";
                mensaje.innerText = "¡Increíble! Encontraste todas las parejas de multiplicaciones muy rápido. ¡Eres una campeona!";
            } else {
                titulo.innerText = "¡Buen trabajo! ";
                mensaje.innerText = "¡Lo lograste! Completaste el memorama con éxito. ¡Sigue jugando para mejorar tu velocidad mental!";
            }

            document.getElementById("pantallaFinalMemorama").style.display = "flex";
        }

        document.addEventListener("DOMContentLoaded", function() {
            crearTablero();
        });
    </script>
</body>
</html>