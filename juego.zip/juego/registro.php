<?php
include 'conexion.php';
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre   = isset($_POST['nombre']) ? mysqli_real_escape_string($conn, $_POST['nombre']) : '';
    $paterno  = isset($_POST['paterno']) ? mysqli_real_escape_string($conn, $_POST['paterno']) : '';
    $materno  = isset($_POST['materno']) ? mysqli_real_escape_string($conn, $_POST['materno']) : '';
    $usuario  = isset($_POST['usuario']) ? mysqli_real_escape_string($conn, $_POST['usuario']) : '';
    $pass_raw = isset($_POST['password']) ? $_POST['password'] : '';

    if (!empty($nombre) && !empty($usuario) && !empty($pass_raw)) {
        $pass_encriptada = password_hash($pass_raw, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO jugadoras (nombre, apellido_paterno, apellido_materno, usuario, contrasena) 
                VALUES ('$nombre', '$paterno', '$materno', '$usuario', '$pass_encriptada')";

        if (mysqli_query($conn, $sql)) {
            session_start();
            $_SESSION['usuario'] = $usuario;
            $_SESSION['nombre_completo'] = $nombre;

            $mensaje = "¡Usuario registrado correctamente! Ya puedes darle al botón Jugar.";
        } else {
            $mensaje = "El nombre de usuario ya está en uso.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Niñas Matemáticas - Registro</title>
    <style>
        :root { --rosa-principal: #e05286; --rosa-tarjeta: #f2cbd6; --rosa-fondo: #f9ecef; --blanco: #ffffff; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); display: flex; flex-direction: column; min-height: 100vh; }
        .header-nav { background-color: var(--rosa-principal); padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; color: white; }
        .contenedor-registro { display: flex; justify-content: center; align-items: center; flex: 1; padding: 20px; }
        .tarjeta-registro { background-color: var(--rosa-tarjeta); width: 100%; max-width: 440px; padding: 25px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.05); }
        .avatar-zona { text-align: center; margin-bottom: 15px; }
        .formulario-inputs { display: flex; flex-direction: column; gap: 10px; }
        .grupo-input { display: flex; flex-direction: column; gap: 4px; }
        .grupo-input label { color: var(--rosa-principal); font-weight: bold; font-size: 0.9rem; }
        .grupo-input input { border: none; padding: 10px; border-radius: 8px; font-size: 1rem; outline: none; }
        .botones-formulario { display: flex; gap: 15px; margin-top: 15px; }
        .btn-submit { background-color: var(--rosa-principal); color: white; border: none; padding: 12px; border-radius: 10px; font-weight: bold; cursor: pointer; flex: 1; }
        .btn-jugar { background-color: #b577ce; color: white; text-decoration: none; padding: 12px; border-radius: 10px; font-weight: bold; text-align: center; flex: 1; }
        .alerta { background-color: white; color: var(--rosa-principal); padding: 10px; border-radius: 8px; text-align: center; font-weight: bold; margin-bottom: 10px; }
        .btn-top { background-color: white; color: var(--rosa-principal); text-decoration: none; padding: 8px 15px; border-radius: 20px; font-weight: bold; }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Niñas Matemáticas</h1>
        <a href="iniciar.php" class="btn-top">Iniciar</a>
    </header>

    <div class="contenedor-registro">
        <div class="tarjeta-registro">
            <div class="avatar-zona">
                <img src="Capibara.jpeg" alt="capibara" style="width: 85px; height: 85px; border-radius: 50%;">
                <h2 style="color: var(--rosa-principal); margin-top: 5px;">Registro</h2>
            </div>

            <?php if(!empty($mensaje)): ?>
                <div class="alerta"><?php echo $mensaje; ?></div>
            <?php endif; ?>

            <form id="formRegistro" action="registro.php" method="POST" class="formulario-inputs">
                <div class="grupo-input"><label>Nombre</label><input type="text" name="nombre" required></div>
                <div class="grupo-input"><label>Apellido paterno</label><input type="text" name="paterno" required></div>
                <div class="grupo-input"><label>Apellido materno</label><input type="text" name="materno" required></div>
                <div class="grupo-input"><label>Usuario</label><input type="text" name="usuario" required></div>
                <div class="grupo-input"><label>Contraseña</label><input type="password" id="pass1" name="password" required></div>
                <div class="grupo-input"><label>Verificar contraseña</label><input type="password" id="pass2" required></div>
                
                <div class="botones-formulario">
                    <button type="submit" class="btn-submit">Registrar</button>
                    <a href="seleccion.php" class="btn-jugar">Jugar</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('formRegistro').addEventListener('submit', function(evento) {
            const p1 = document.getElementById('pass1').value;
            const p2 = document.getElementById('pass2').value;

            if (p1 !== p2) {
                evento.preventDefault(); 
                alert('¡Las contraseñas no coinciden! Por favor, verifica de nuevo.');
            }
        });
    </script>
</body>
</html>