<?php 
session_start(); 
if(isset($_SESSION['usuario'])) {
    header("Location: index.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Inicio</title>
    <style>
        :root {
            --rosa-principal: #e05286;
            --rosa-fondo: #f9ecef;
            --blanco: #ffffff;
            --texto-oscuro: #5c3a44;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); color: var(--texto-oscuro); min-height: 100vh; display: flex; flex-direction: column; }

        .header-nav {
            background-color: var(--rosa-principal);
            padding: 15px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--blanco);
        }
        .logo-txt { font-size: 1.8rem; font-weight: bold; }
        .btn-top {
            background-color: var(--blanco); color: var(--rosa-principal);
            text-decoration: none; padding: 8px 18px; border-radius: 20px; font-weight: bold;
        }

        .contenedor-principal {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 30px;
        }

        .zona-animada {
            width: 200px;
            height: 200px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        

        .imagen-giratoria {
            width: 100%;
            height: 100%;
            border-radius: 10%;
            object-fit: cover;
            border: 5px solid var(--rosa-principal);
            animation: giroPausado 3s ease-in-out infinite; 
        }

        @keyframes giroPausado {
            0% { transform: rotate(0deg); }
            70% { transform: rotate(0deg); } 
            100% { transform: rotate(360deg); }
        }

        .btn-iniciar {
            background-color: #b577ce; color: var(--blanco);
            font-size: 1.6rem; padding: 14px 70px; border-radius: 30px;
            text-decoration: none; font-weight: bold; transition: background-color 0.4s ease, transform 0.2s;
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
            display: inline-block;
        }
        .btn-iniciar:hover {
            background-color: var(--rosa-principal);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 class="logo-txt">Niñas Matemáticas</h1>
        <a href="iniciar.php" class="btn-top">Iniciar sesión</a>
    </header>

    <main class="contenedor-principal">
        <div class="zona-animada">
            <img src="capibara.jpeg" alt="Capibara" class="imagen-giratoria">
        </div>
        <div class="zona-acciones">
            <a href="registro.php" class="btn-iniciar" id="botonDinamico">Iniciar</a>
        </div>
    </main>

</body>
</html>