<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: iniciar.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Menú Principal</title>
    <style>
        :root {
            --rosa-principal: #e05286;
            --rosa-fondo: #f9ecef;
            --blanco: #ffffff;
            --morado-botones: #b577ce;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-color: var(--rosa-fondo);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .header-nav {
            background-color: var(--rosa-principal);
            padding: 0 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            height: 80px;
        }

        .header-nav h1 {
            font-size: 1.8rem;
            font-weight: bold;
        }

        .info-alumna {
            font-size: 1.2rem;
            font-weight: bold;
        }

        .contenedor-menu {
            max-width: 1300px; 
            margin: 30px auto;
            padding: 0 20px;
            text-align: center;
            flex: 1;
        }

        .titulo-bienvenida {
            color: var(--rosa-principal);
            font-size: 2.2rem;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .grid-juegos {
            display: grid;
            grid-template-columns: repeat(4, 1fr); 
            gap: 20px;
            justify-content: center;
        }

        .tarjeta-modo {
            background-color: var(--blanco);
            border: 3px solid var(--rosa-principal);
            border-radius: 16px;
            padding: 15px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 6px 12px rgba(0,0,0,0.03);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .tarjeta-modo:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        }

        .tarjeta-modo h2 {
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 10px;
        }

        .contenedor-icono-juego {
            width: 100%;
            height: 90px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 10px;
        }

        .contenedor-icono-juego img {
            max-height: 100%;
            max-width: 95%;
            object-fit: contain;
        }

        .tarjeta-modo p {
            font-size: 0.85rem;
            color: #666;
            line-height: 1.3;
            margin-bottom: 15px;
            flex-grow: 1;
        }

        .btn-entrar {
            background-color: var(--morado-botones);
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9rem;
            transition: background-color 0.2s;
            width: 100%;
            display: block;
        }

        .btn-entrar:hover {
            background-color: #9c5cb8;
        }

        @media (max-width: 992px) {
            .grid-juegos {
                grid-template-columns: repeat(2, 1fr); 
            }
        }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1>Niñas Matemáticas</h1>
        <div class="info-alumna">Alumna: <?php echo htmlspecialchars($_SESSION['usuario']); ?></div>
    </header>

    <div class="contenedor-menu">
        <h2 class="titulo-bienvenida">¿Qué vas a jugar hoy?</h2>

        <div class="grid-juegos">

            <div class="tarjeta-modo">
                <h2>Juego de Divisiones</h2>
                <div class="contenedor-icono-juego">
                    <img src="division.png" alt="Divisiones">
                </div>
                <p>Responde contrarreloj operaciones directas con su respuesta.</p>
                <a href="divisiones.php" class="btn-entrar">Entrar a Divisiones</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Memorama</h2>
                <div class="contenedor-icono-juego">
                    <img src="memorama.jpg" alt="Memorama">
                </div>
                <p>Encuentra los pares uniendo la multiplicación con su respuesta.</p>
                <a href="memorama2.php" class="btn-entrar">Entrar a Memorama</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Fracciones</h2>
                <div class="contenedor-icono-juego">
                    <img src="fraccion.jpg" alt="Fracciones">
                </div>
                <p>Responde contrarreloj operaciones directas de fracciones.</p>
                <a href="fraccion.php" class="btn-entrar">Entrar a Fracciones</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Multiplicaciones</h2>
                <div class="contenedor-icono-juego">
                    <img src="multiplicacion.jpg" alt="Multiplicaciones">
                </div>
                <p>Responde contrarreloj operaciones directas de multiplicación.</p>
                <a href="multiplicacion.php" class="btn-entrar">Entrar a Multiplicaciones</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Divisiones difíciles</h2>
                <div class="contenedor-icono-juego">
                    <img src="division.png" alt="Multiplicaciones Difíciles">
                </div>
                <p>Responde contrarreloj operaciones más avanzadas.</p>
                <a href="divisiones2.php" class="btn-entrar">Entrar a Divisiones difíciles</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Memorama difícil</h2>
                <div class="contenedor-icono-juego">
                    <img src="memorama.jpg" alt="Memorama Difícil">
                </div>
                <p>Responde contrarreloj el memorama más difícil.</p>
                <a href="memorama.php" class="btn-entrar">Entrar a memorama difícil</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Fracciones difíciles</h2>
                <div class="contenedor-icono-juego">
                    <img src="fraccion.jpg" alt="Fracciones Difíciles">
                </div>
                <p>Responde contrarreloj las operaciones más difíciles.</p>
                <a href="fraccion2.php" class="btn-entrar">Entrar a fracciones difíciles</a>
            </div>

            <div class="tarjeta-modo">
                <h2>Multiplicaciones difíciles</h2>
                <div class="contenedor-icono-juego">
                    <img src="multiplicacion.jpg" alt="Multiplicaciones Difíciles">
                </div>
                <p>Responde contrarreloj las Multiplicaciones más difíciles.</p>
                <a href="multiplicacion2.php" class="btn-entrar">Entrar a multiplicaciones difíciles</a>
            </div>

        </div>
    </div>

</body>
</html>