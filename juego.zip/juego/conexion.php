<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "bd_juego";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>