<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: in.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Fracciones Súper Reto</title>
    <style>
        :root { --rosa-principal: #e05286; --rosa-fondo: #f9ecef; --blanco: #ffffff; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); text-align: center; display: flex; flex-direction: column; min-height: 100vh; }
        .header-nav { background-color: var(--rosa-principal); padding: 10px 40px; display: flex; justify-content: space-between; color: white; align-items: center; }
        .btn-capibara-menu { display: inline-block; width: 50px; height: 50px; border-radius: 10px; border: 3px solid var(--blanco); overflow: hidden; box-shadow: 0 4px 8px rgba(0,0,0,0.15); transition: transform 0.2s, border-color 0.2s; }
        .btn-capibara-menu:hover { transform: scale(1.1); border-color: #ffcb42; }
        .btn-capibara-menu img { width: 100%; height: 100%; object-fit: cover; }
        .contenedor-principal { display: flex; justify-content: center; align-items: center; flex: 1; padding: 20px; }
        .contenedor-juego { width: 100%; max-width: 600px; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.05); border: 4px solid var(--rosa-principal); position: relative; }
        .marcador { display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: bold; margin-bottom: 20px; color: #b577ce; }
        .barra-tiempo-contenedor { width: 100%; height: 15px; background-color: #ddd; border-radius: 10px; overflow: hidden; margin-bottom: 25px; }
        .barra-tiempo { width: 100%; height: 100%; background-color: #4a90e2; }
        .pregunta-texto { display: flex; justify-content: center; align-items: center; font-size: 3.5rem; font-weight: bold; color: var(--rosa-principal); margin-bottom: 25px; gap: 15px; }
        .fraccion { display: inline-flex; flex-direction: column; align-items: center; justify-content: center; line-height: 1; }
        .numerador { border-bottom: 4px solid var(--rosa-principal); padding-bottom: 5px; min-width: 45px; text-align: center; }
        .denominador { padding-top: 5px; min-width: 45px; text-align: center; }
        .opciones-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
        .btn-opcion { background-color: #b577ce; color: white; border: none; padding: 15px; border-radius: 10px; cursor: pointer; transition: 0.2s; display: flex; justify-content: center; align-items: center; }
        .btn-opcion:hover { transform: scale(1.03); background-color: #a262bd; }
        .btn-opcion .fraccion { font-size: 1.8rem; font-weight: bold; }
        .btn-opcion .numerador { border-bottom: 3px solid white; }
        .capa-bloqueo { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(92, 58, 68, 0.6); justify-content: center; align-items: center; z-index: 100; }
        .tarjeta-final { background: white; border: 5px solid var(--rosa-principal); padding: 35px; border-radius: 20px; max-width: 450px; width: 90%; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .contenedor-puntos-finales { background-color: var(--rosa-fondo); padding: 20px; border-radius: 15px; margin: 20px 0; border: 2px dashed var(--rosa-principal); }
        .btn-final-volver { background-color: #b577ce; color: white; padding: 14px 35px; font-size: 1.2rem; font-weight: bold; border: none; border-radius: 30px; cursor: pointer; margin-top: 15px; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Niñas Matemáticas </h1>
        <a href="seleccion.php" class="btn-capibara-menu" title="Volver al Menú"><img src="capibara.jpeg" alt="Menú"></a>
    </header>
    <div class="contenedor-principal">
        <main class="contenedor-juego">
            <div class="marcador">
                <div>Puntos: <span id="puntos-txt">0</span></div>
                <div>Pregunta: <span id="ronda-txt">1</span></div>
            </div>
            <div class="barra-tiempo-contenedor"><div class="barra-tiempo" id="barra"></div></div>
            <div class="pregunta-texto" id="pregunta-contenedor"></div>
            <div class="opciones-grid">
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc0">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc1">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc2">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc3">-</button>
            </div>
        </main>
    </div>
    <div class="capa-bloqueo" id="pantallaFinal">
        <div class="tarjeta-final">
            <h2 id="titulo-final" style="color: var(--rosa-principal); font-size: 2.3rem;">-</h2>
            <p id="mensaje-final">-</p>
            <div class="contenedor-puntos-finales">
                <span style="font-size: 1.4rem; font-weight: bold; color: var(--rosa-principal);">Puntuación Súper Reto:</span><br>
                <span style="font-size: 3.5rem; font-weight: bold; color: #b577ce;" id="puntos-finales-num">0</span> puntos
            </div>
            <a href="seleccion.php" class="btn-final-volver">Volver al Menú Principal</a>
        </div>
    </div>
    <script>
        let puntos = 0, ronda = 1, numCorrecto = 0, denCorrecto = 0, tiempoRestante = 100, temporizadorIntervalo;
        
        function generarPregunta() {
            let den1 = Math.floor(Math.random() * 4) + 2; 
            let den2 = den1;
            while(den2 === den1) { den2 = Math.floor(Math.random() * 4) + 2; }
            
            let num1 = Math.floor(Math.random() * 2) + 1;
            let num2 = Math.floor(Math.random() * 2) + 1;

            denCorrecto = den1 * den2;
            numCorrecto = (num1 * den2) + (num2 * den1);

            const contenedor = document.getElementById("pregunta-contenedor");
            contenedor.innerHTML = `
                <div class="fraccion"><div class="numerador">${num1}</div><div class="denominador">${den1}</div></div>
                <span>+</span>
                <div class="fraccion"><div class="numerador">${num2}</div><div class="denominador">${den2}</div></div>
            `;
            document.getElementById("ronda-txt").innerText = ronda;

            let opciones = [{n: numCorrecto, d: denCorrecto}];
            while(opciones.length < 4) {
                let falsoNum = numCorrecto + (Math.floor(Math.random() * 4) - 2);
                if(falsoNum > 0 && !opciones.some(o => o.n === falsoNum)) {
                    opciones.push({n: falsoNum, d: denCorrecto});
                }
            }
            opciones.sort(() => Math.random() - 0.5);

            for(let i = 0; i < 4; i++) {
                let boton = document.getElementById(`opc${i}`);
                boton.innerHTML = `<div class="fraccion"><div class="numerador">${opciones[i].n}</div><div class="denominador">${opciones[i].d}</div></div>`;
                boton.dataset.num = opciones[i].n;
                boton.style.backgroundColor = "#b577ce";
                boton.disabled = false;
            }
            iniciarTiempo();
        }
        function iniciarTiempo() {
            clearInterval(temporizadorIntervalo); tiempoRestante = 100;
            const barra = document.getElementById("barra");
            temporizadorIntervalo = setInterval(() => {
                tiempoRestante -= 1; barra.style.width = tiempoRestante + "%";
                if (tiempoRestante <= 0) { clearInterval(temporizadorIntervalo); siguienteRonda(); }
            }, 250); 
        }
        function verificarRespuesta(botonSeleccionado) {
            clearInterval(temporizadorIntervalo);
            for(let i = 0; i < 4; i++) document.getElementById(`opc${i}`).disabled = true;
            if(parseInt(botonSeleccionado.dataset.num) === numCorrecto) {
                puntos += 10; document.getElementById("puntos-txt").innerText = puntos;
                botonSeleccionado.style.backgroundColor = "#4caf50";
            } else {
                botonSeleccionado.style.backgroundColor = "#f44336";
                for(let i = 0; i < 4; i++) {
                    let b = document.getElementById(`opc${i}`);
                    if(parseInt(b.dataset.num) === numCorrecto) b.style.backgroundColor = "#4caf50";
                }
            }
            setTimeout(siguienteRonda, 1800);
        }
        function siguienteRonda() {
            if (ronda < 10) { ronda++; generarPregunta(); } else { mostrarPuntuacionFinal(); }
        }
        function mostrarPuntuacionFinal() {
            document.getElementById("puntos-finales-num").innerText = puntos;
            let t = document.getElementById("titulo-final"), m = document.getElementById("mensaje-final");
            if (puntos >= 70) { t.innerText = "¡Súper Matemática de Fracciones! "; m.innerText = "¡Dominas las fracciones con diferente denominador! Eres Increíble."; }
            else { t.innerText = "¡Vas por buen camino! "; m.innerText = "Este era el reto más difícil de toda la app. ¡Hiciste un esfuerzo maravilloso!"; }
            document.getElementById("pantallaFinal").style.display = "flex";
        }
        document.addEventListener("DOMContentLoaded", generarPregunta);
    </script>
</body>
</html>