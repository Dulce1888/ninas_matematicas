<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Juego de Multiplicaciones</title>
    <style>
        :root { 
            --rosa-principal: #e05286; 
            --rosa-tarjeta: #f2cbd6;
            --rosa-fondo: #f9ecef; 
            --blanco: #ffffff; 
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); text-align: center; display: flex; flex-direction: column; min-height: 100vh; }
        
        .header-nav { 
            background-color: var(--rosa-principal); 
            padding: 10px 40px; 
            display: flex; 
            justify-content: space-between; 
            color: white; 
            align-items: center; 
        }
        
        .btn-capibara-menu {
            display: inline-block;
            width: 50px;
            height: 50px;
            border-radius: 10px;
            border: 3px solid var(--blanco);
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            transition: transform 0.2s, border-color 0.2s;
        }
        .btn-capibara-menu:hover { transform: scale(1.1); border-color: #ffcb42; }
        .btn-capibara-menu img { width: 100%; height: 100%; object-fit: cover; }
        
        .contenedor-principal { display: flex; justify-content: center; align-items: center; flex: 1; padding: 20px; }
        .contenedor-juego { width: 100%; max-width: 600px; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.05); border: 4px solid var(--rosa-principal); position: relative; }
        .marcador { display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: bold; margin-bottom: 20px; color: #b577ce; }
        
        .barra-tiempo-contenedor { width: 100%; height: 15px; background-color: #ddd; border-radius: 10px; overflow: hidden; margin-bottom: 25px; }
        .barra-tiempo { width: 100%; height: 100%; background-color: #4a90e2; }
        
        .pregunta-texto { font-size: 4rem; font-weight: bold; color: var(--rosa-principal); margin-bottom: 25px; }
        .opciones-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
        .btn-opcion { background-color: #b577ce; color: white; border: none; padding: 18px; font-size: 1.6rem; font-weight: bold; border-radius: 10px; cursor: pointer; transition: 0.2s; }
        .btn-opcion:hover { transform: scale(1.03); background-color: #a262bd; }

        .capa-bloqueo {
            display: none;
            position: fixed; 
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(92, 58, 68, 0.6); 
            justify-content: center; align-items: center;
            z-index: 100;
        }
        .tarjeta-final {
            background: white; border: 5px solid var(--rosa-principal); padding: 35px; border-radius: 20px;
            max-width: 450px; width: 90%; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            animation: animacionEntrada 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        @keyframes animacionEntrada { from { transform: scale(0.7); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .contenedor-puntos-finales { background-color: var(--rosa-fondo); padding: 20px; border-radius: 15px; margin: 20px 0; border: 2px dashed var(--rosa-principal); }
        .btn-final-volver { background-color: #b577ce; color: white; padding: 14px 35px; font-size: 1.2rem; font-weight: bold; border: none; border-radius: 30px; cursor: pointer; margin-top: 15px; text-decoration: none; display: inline-block; box-shadow: 0 4px 8px rgba(0,0,0,0.1); transition: 0.2s; }
        .btn-final-volver:hover { background-color: var(--rosa-principal); transform: translateY(-2px); }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Niñas Matemáticas</h1>
        <a href="seleccion.php" class="btn-capibara-menu" title="Volver al Menú">
            <img src="capibara.jpeg" alt="Menú">
        </a>
    </header>

    <div class="contenedor-principal">
        <main class="contenedor-juego">
            <div class="marcador">
                <div>Puntos: <span id="puntos-txt">0</span></div>
                <div>Pregunta: <span id="ronda-txt">1</span></div>
            </div>

            <div class="barra-tiempo-contenedor">
                <div class="barra-tiempo" id="barra"></div>
            </div>

            <div class="pregunta-texto" id="pregunta">... x ...</div>

            <div class="opciones-grid">
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc0">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc1">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc2">-</button>
                <button class="btn-opcion" onclick="verificarRespuesta(this)" id="opc3">-</button>
            </div>
        </main>
    </div>

    <div class="capa-bloqueo" id="pantallaFinal">
        <div class="tarjeta-final">
            <h2 id="titulo-final" style="color: var(--rosa-principal); font-size: 2.3rem; margin-bottom: 10px;">-</h2>
            <p id="mensaje-final" style="font-size: 1.1rem; color: #5c3a44;">-</p>
            
            <div class="contenedor-puntos-finales">
                <span style="font-size: 1.4rem; font-weight: bold; color: var(--rosa-principal);">Tu puntuación es:</span>
                <br>
                <span style="font-size: 3.5rem; font-weight: bold; color: #b577ce;" id="puntos-finales-num">0</span> 
                <span style="font-size: 1.5rem; font-weight: bold; color: #b577ce;">puntos</span>
            </div>

            <a href="seleccion.php" class="btn-final-volver">Volver al Menú Principal</a>
        </div>
    </div>

    <script {>
        let puntos = 0;
        let ronda = 1;
        let respuestaCorrecta = 0;
        let tiempoRestante = 100; 
        let temporizadorIntervalo;

        function generarPregunta() {
            let numero1 = Math.floor(Math.random() * 9) + 2; // Del 2 al 10
            let numero2 = Math.floor(Math.random() * 9) + 1; // Del 1 al 9
            respuestaCorrecta = numero1 * numero2; 

            document.getElementById("pregunta").innerText = `${numero1} x ${numero2}`;
            document.getElementById("ronda-txt").innerText = ronda;

            let opciones = [respuestaCorrecta];
            while(opciones.length < 4) {
                let falso = (Math.floor(Math.random() * 9) + 2) * (Math.floor(Math.random() * 9) + 1);
                if(!opciones.includes(falso)) opciones.push(falso);
            }
            
            opciones.sort(() => Math.random() - 0.5);

            for(let i = 0; i < 4; i++) {
                let boton = document.getElementById(`opc${i}`);
                boton.innerText = opciones[i];
                boton.style.backgroundColor = "#b577ce"; 
                boton.disabled = false;
            }

            iniciarTiempo();
        }

        function iniciarTiempo() {
            clearInterval(temporizadorIntervalo);
            tiempoRestante = 100;
            const barra = document.getElementById("barra");
            
            temporizadorIntervalo = setInterval(() => {
                tiempoRestante -= 1; 
                barra.style.width = tiempoRestante + "%";
                if (tiempoRestante <= 0) {
                    clearInterval(temporizadorIntervalo);
                    siguienteRonda();
                }
            }, 100); 
        }

        function verificarRespuesta(botonSeleccionado) {
            clearInterval(temporizadorIntervalo);
            for(let i = 0; i < 4; i++) document.getElementById(`opc${i}`).disabled = true;

            let respuestaAlumna = parseInt(botonSeleccionado.innerText);

            if(respuestaAlumna === respuestaCorrecta) {
                puntos += 10;
                document.getElementById("puntos-txt").innerText = puntos;
                botonSeleccionado.style.backgroundColor = "#4caf50"; 
            } else {
                botonSeleccionado.style.backgroundColor = "#f44336"; 
                for(let i = 0; i < 4; i++) {
                    let b = document.getElementById(`opc${i}`);
                    if(parseInt(b.innerText) === respuestaCorrecta) {
                        b.style.backgroundColor = "#4caf50";
                    }
                }
            }
            setTimeout(siguienteRonda, 1200); 
        }

        function siguienteRonda() {
            if (ronda < 10) {
                ronda++;
                generarPregunta();
            } else {
                clearInterval(temporizadorIntervalo);
                mostrarPuntuacionFinal();
            }
        }

        function mostrarPuntuacionFinal() {
            document.getElementById("puntos-finales-num").innerText = puntos;
            let titulo = document.getElementById("titulo-final");
            let mensaje = document.getElementById("mensaje-final");

            if (puntos >= 70) {
                titulo.innerText = "¡Súper Multiplicadora! ";
                mensaje.innerText = "¡Excelente trabajo! Te sabes perfectamente las tablas de multiplicar. ¡Sigue brillando!";
            } else {
                titulo.innerText = "¡Buen intento! ";
                mensaje.innerText = "¡Sigue adelante! Practicar las tablas te ayudará a resolver cualquier reto matemático. ¡Tú puedes!";
            }
            document.getElementById("pantallaFinal").style.display = "flex";
        }

        document.addEventListener("DOMContentLoaded", generarPregunta);
    </script>
</body>
</html>