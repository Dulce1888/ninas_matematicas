<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: iniciar.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Divisiones Avanzadas</title>
    <style>
        :root {
            --rosa-principal: #e05286;
            --rosa-fondo: #f9ecef;
            --blanco: #ffffff;
            --morado-botones: #b577ce;
            --azul-tiempo: #2196f3; 
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-color: var(--rosa-fondo);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header-nav {
            background-color: var(--rosa-principal);
            padding: 0 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            height: 80px;
        }

        .header-nav h1 {
            font-size: 1.8rem;
            font-weight: bold;
        }

        .enlace-capibara {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 60px;
            height: 60px;
            background-color: var(--blanco);
            border-radius: 50%;
            padding: 2px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.2s ease-in-out;
            text-decoration: none;
        }

        .enlace-capibara:hover {
            transform: scale(1.1);
        }

        .img-menu-capibara {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .contenedor-principal {
            display: flex;
            justify-content: center;
            align-items: center;
            flex: 1;
            padding: 20px;
        }

        .tarjeta-juego {
            background: white;
            border: 4px solid var(--rosa-principal);
            border-radius: 20px;
            padding: 30px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.05);
            text-align: center;
        }

        .info-progreso {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--morado-botones);
            font-weight: bold;
            font-size: 1.1rem;
            margin-bottom: 12px;
        }

        .barra-progreso-bg {
            background-color: #e0e0e0;
            border-radius: 10px;
            height: 14px;
            width: 100%;
            margin-bottom: 30px;
            overflow: hidden;
        }

        .barra-progreso-llenado {
            background-color: var(--azul-tiempo);
            height: 100%;
            width: 100%;
            transition: width 1s linear;
        }

        .operacion-matematica {
            font-size: 4rem;
            font-weight: bold;
            color: var(--rosa-principal);
            margin-bottom: 30px;
        }

        .grid-opciones {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .btn-opcion {
            background-color: var(--morado-botones);
            color: white;
            border: none;
            padding: 18px;
            font-size: 1.3rem;
            font-weight: bold;
            border-radius: 12px;
            cursor: pointer;
            transition: background-color 0.2s, transform 0.1s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .btn-opcion:hover {
            background-color: #9c5cb8;
            transform: translateY(-2px);
        }

        .btn-opcion.correcto {
            background-color: #4caf50 !important;
        }

        .btn-opcion.incorrecto {
            background-color: #f44336 !important;
        }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1>Niñas Matemáticas</h1>
        <a href="seleccion.php" class="enlace-capibara" title="Volver al Menú Principal">
            <img src="capibara.jpeg" alt="Volver al Menú" class="img-menu-capibara">
        </a>
    </header>

    <div class="contenedor-principal">
        <main class="tarjeta-juego">
            <div class="info-progreso">
                <span>Puntos: <span id="puntos">0</span></span>
                <span>Pregunta: <span id="pregunta-actual">1</span> / 10</span>
            </div>
            
            <div class="barra-progreso-bg">
                <div class="barra-progreso-llenado" id="barra-tiempo"></div>
            </div>

            <div class="operacion-matematica" id="operacion">... ÷ ...</div>

            <div class="grid-opciones">
                <button class="btn-opcion" onclick="comprobarRespuesta(this)" id="opc0">-</button>
                <button class="btn-opcion" onclick="comprobarRespuesta(this)" id="opc1">-</button>
                <button class="btn-opcion" onclick="comprobarRespuesta(this)" id="opc2">-</button>
                <button class="btn-opcion" onclick="comprobarRespuesta(this)" id="opc3">-</button>
            </div>
        </main>
    </div>

    <script>
        let puntos = 0;
        let preguntaActual = 1;
        const totalPreguntas = 10;
        let respuestaCorrecta = 0;
        
        const tiempoMaximo = 45; 
        let tiempoRestante = tiempoMaximo; 
        let temporizadorIntervalo;

        function iniciarReloj() {
            temporizadorIntervalo = setInterval(() => {
                tiempoRestante--;

                let porcentajeRestante = (tiempoRestante / tiempoMaximo) * 100;
                document.getElementById("barra-tiempo").style.width = porcentajeRestante + "%";

                if (tiempoRestante <= 0) {
                    clearInterval(temporizadorIntervalo);
                    bloquearBotones();
                    alert(" ¡Se agotó el tiempo! Juego Terminado. Puntos logrados: " + puntos);
                    window.location.href = "seleccion.php";
                }
            }, 1000);
        }

        function generarEjercicio() {
            if (preguntaActual > totalPreguntas) {
                clearInterval(temporizadorIntervalo);
                alert(" ¡Felicidades, completaste todos los ejercicios! Puntos totales: " + puntos);
                window.location.href = "seleccion.php";
                return;
            }

            document.getElementById("pregunta-actual").innerText = preguntaActual;
            document.getElementById("puntos").innerText = puntos;

            let divisor = Math.floor(Math.random() * 7) + 3;       
            let cociente = Math.floor(Math.random() * 41) + 10;    
            let dividendo = divisor * cociente;                    

            respuestaCorrecta = cociente;
            document.getElementById("operacion").innerText = `${dividendo} ÷ ${divisor}`;

            let opciones = [respuestaCorrecta];
            while (opciones.length < 4) {
                let desvio = Math.floor(Math.random() * 9) - 4; 
                let opcionFalsa = respuestaCorrecta + desvio;
                if (opcionFalsa > 0 && !opciones.includes(opcionFalsa)) {
                    opciones.push(opcionFalsa);
                }
            }
            opciones.sort(() => Math.random() - 0.5);

            for (let i = 0; i < 4; i++) {
                let btn = document.getElementById("opc" + i);
                btn.innerText = opciones[i];
                btn.className = "btn-opcion"; 
                btn.disabled = false;
            }
        }

        function comprobarRespuesta(boton) {
            bloquearBotones(); 
            let respuestaSeleccionada = parseInt(boton.innerText);

            if (respuestaSeleccionada === respuestaCorrecta) {
                puntos += 10;
                boton.classList.add("correcto"); 
            } else {
                boton.classList.add("incorrecto"); 
                for (let i = 0; i < 4; i++) {
                    let btn = document.getElementById("opc" + i);
                    if (parseInt(btn.innerText) === respuestaCorrecta) {
                        btn.classList.add("correcto");
                    }
                }
            }

            preguntaActual++;
            setTimeout(generarEjercicio, 1000);
        }

        function bloquearBotones() {
            for (let i = 0; i < 4; i++) {
                document.getElementById("opc" + i).disabled = true;
            }
        }

        window.onload = function() {
            generarEjercicio();
            iniciarReloj();
        };
    </script>
</body>
</html>