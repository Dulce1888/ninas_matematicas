<?php
include 'conexion.php';
session_start();

$error = "";

if (isset($_SESSION['usuario'])) {
    header("Location: seleccion.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = isset($_POST['usuario']) ? mysqli_real_escape_string($conn, $_POST['usuario']) : '';
    $pass = isset($_POST['password']) ? $_POST['password'] : '';

    if (!empty($user) && !empty($pass)) {
        $sql = "SELECT * FROM jugadoras WHERE usuario = '$user'";
        $resultado = mysqli_query($conn, $sql);

        if ($resultado && mysqli_num_rows($resultado) > 0) {
            $fila = mysqli_fetch_assoc($resultado);
            
            if (password_verify($pass, $fila['contrasena'])) {
                $_SESSION['usuario'] = $fila['usuario'];
                $_SESSION['nombre_completo'] = $fila['nombre'];
                
                header("Location: seleccion.php");
                exit();
            } else {
                $error = "La contraseña es incorrecta. ¡Inténtalo de nuevo!";
            }
        } else {
            $error = "La jugadora no existe. ¡Regístrate primero!";
        }
    } else {
        $error = "Por favor, llena todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Niñas Matemáticas - Iniciar Sesión</title>
    <style>
        :root { --rosa-principal: #e05286; --rosa-tarjeta: #f2cbd6; --rosa-fondo: #f9ecef; --blanco: #ffffff; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--rosa-fondo); display: flex; flex-direction: column; min-height: 100vh; }
        .header-nav { background-color: var(--rosa-principal); padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; color: var(--blanco); }
        .contenedor-login { display: flex; justify-content: center; align-items: center; flex: 1; padding: 20px; }
        .tarjeta-login { background-color: var(--rosa-tarjeta); width: 100%; max-width: 400px; padding: 30px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.05); text-align: center; }
        .formulario-inputs { display: flex; flex-direction: column; gap: 15px; text-align: left; margin-top: 20px; }
        .grupo-input { display: flex; flex-direction: column; gap: 5px; }
        .grupo-input label { color: var(--rosa-principal); font-weight: bold; }
        .grupo-input input { border: none; padding: 12px; border-radius: 8px; width: 100%; font-size: 1rem; outline: none; }
        .btn-submit { background-color: var(--rosa-principal); color: white; border: none; padding: 12px; border-radius: 10px; font-weight: bold; cursor: pointer; width: 100%; font-size: 1.1rem; margin-top: 10px; }
        .alerta-error { background-color: white; color: var(--rosa-principal); padding: 10px; border-radius: 8px; text-align: center; font-weight: bold; }
        .btn-regresar { display: block; margin-top: 15px; color: #b577ce; text-decoration: none; font-weight: bold; font-size: 0.9rem; }
    </style>
</head>
<body>

    <header class="header-nav">
        <h1 style="font-size: 1.8rem; font-weight: bold;">Niñas Matemáticas</h1>
    </header>

    <div class="contenedor-login">
        <div class="tarjeta-login">
            <h2 style="color: var(--rosa-principal); font-size: 1.8rem;">Iniciar Sesión</h2>
            <br>
            <?php if(!empty($error)): ?>
                <div class="alerta-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="iniciar.php" method="POST" class="formulario-inputs">
                <div class="grupo-input">
                    <label>Usuario</label>
                    <input type="text" name="usuario" required>
                </div>
                <div class="grupo-input">
                    <label>Contraseña</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn-submit">Ingresar</button>
            </form>
            <a href="registro.php" class="btn-regresar">¿No tienes cuenta? Regístrate aquí</a>
        </div>
    </div>
</body>
</html>